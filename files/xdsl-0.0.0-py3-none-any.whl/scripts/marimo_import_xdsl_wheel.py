async def _():
    async def import_xdsl():
        from urllib.parse import urljoin

        import micropip
        from marimo import notebook_location

        location = notebook_location()
        if location is None:
            raise RuntimeError("Could not determine the notebook location")

        # Exported notebooks live at notebooks/html/<name>/ below the site root.
        # Resolve the wheel relative to that root so deployments under a URL prefix
        # (for example, https://host/project/) keep that prefix.
        wheel_url = urljoin(
            f"{str(location).rstrip('/')}/",
            "../../../xdsl-0.0.0-py3-none-any.whl",
        )
        await micropip.install("xdsl @ " + wheel_url)

    await import_xdsl()
    from xdsl.utils import marimo as xmo

    return xmo
