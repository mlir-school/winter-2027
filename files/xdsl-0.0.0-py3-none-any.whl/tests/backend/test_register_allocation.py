import re
from collections.abc import Sequence
from typing import ClassVar

import pytest
from typing_extensions import override

from xdsl.backend.block_naive_allocator import BlockNaiveAllocator
from xdsl.backend.register_allocatable import (
    HasRegisterConstraints,
    RegisterAllocatableOperation,
    RegisterConstraints,
)
from xdsl.backend.register_allocator import ValueAllocator
from xdsl.backend.register_stack import OutOfRegisters, RegisterStack
from xdsl.backend.register_type import RegisterAllocatedMemoryEffect, RegisterType
from xdsl.builder import Builder
from xdsl.dialects.test import TestAllocatableOp, TestOp, TestRegisterType
from xdsl.ir import Attribute, Block, SSAValue
from xdsl.irdl import (
    IRDLOperation,
    VarConstraint,
    base,
    irdl_attr_definition,
    irdl_op_definition,
    operand_def,
    result_def,
    traits_def,
    var_operand_def,
    var_result_def,
)
from xdsl.utils.exceptions import DiagnosticException, VerifyException
from xdsl.utils.test_value import create_ssa_value


@irdl_attr_definition
class TestAliasRegisterA(RegisterType):
    name = "test.alias_a"

    @classmethod
    def index_by_name(cls) -> dict[str, int]:
        return {"p0": 0, "p1": 1}

    @classmethod
    def infinite_register_prefix(cls):
        return "inf_alias_a_"

    @classmethod
    def register_pool_key(cls) -> str:
        return "test.alias_pool"


@irdl_attr_definition
class TestAliasRegisterB(RegisterType):
    name = "test.alias_b"

    @classmethod
    def index_by_name(cls) -> dict[str, int]:
        return {"q0": 0, "q1": 1}

    @classmethod
    def infinite_register_prefix(cls):
        return "inf_alias_b_"

    @classmethod
    def register_pool_key(cls) -> str:
        return "test.alias_pool"


def op(
    ins: Sequence[SSAValue],
    *out_result_types: Attribute,
    inouts: Sequence[SSAValue] = (),
):
    return TestAllocatableOp(
        ins, inouts, out_result_types, tuple(val.type for val in inouts)
    )


def test_gather_allocated():
    u = TestRegisterType.unallocated()
    x0 = TestRegisterType.from_name("x0")
    x1 = TestRegisterType.from_name("x0")

    @Builder.implicit_region
    def no_preallocated_body() -> None:
        (v1,) = op((), u).results
        (v2,) = op((), u).results
        _op = op((v1, v2), u)
        assert not set(RegisterAllocatedMemoryEffect.iter_used_registers(_op))

    assert not (RegisterAllocatableOperation.all_used_registers(no_preallocated_body))

    @Builder.implicit_region
    def one_preallocated_body() -> None:
        (v1,) = op((), u).results
        (v2,) = op((), x0).results
        _op = op((v1, v2), u)
        assert set(RegisterAllocatedMemoryEffect.iter_used_registers(_op)) == {x0}

    assert RegisterAllocatableOperation.all_used_registers(one_preallocated_body) == {
        x0
    }

    @Builder.implicit_region
    def repeated_preallocated_body() -> None:
        (v1,) = op((), u).results
        (v2,) = op((), x0).results
        (v3,) = op((), x0).results
        _op = op((v1, v2, v3), u)
        assert set(RegisterAllocatedMemoryEffect.iter_used_registers(_op)) == {x0}

    assert RegisterAllocatableOperation.all_used_registers(
        repeated_preallocated_body
    ) == {x0}

    @Builder.implicit_region
    def multiple_preallocated_body() -> None:
        (v1,) = op((), u).results
        (v2,) = op((), x0).results
        (v3,) = op((), x1).results
        _op = op((v1, v2, v3), u)
        assert set(RegisterAllocatedMemoryEffect.iter_used_registers(_op)) == {x0, x1}

        # Test that calling iter_used_registers is deprecated on a function that does
        # not overload it.
        with pytest.deprecated_call():
            assert not set(_op.iter_used_registers())  # pyright: ignore[reportDeprecated]

    assert RegisterAllocatableOperation.all_used_registers(
        multiple_preallocated_body
    ) == {x0, x1}


def test_deprecated_iter_used_registers():
    """
    Test that functions that overload `iter_used_registers` still work as expected but
    raise a deprecation warning.
    """

    x1 = TestRegisterType.from_name("x1")

    @irdl_op_definition
    class TestDepracatedAllocatableOp(IRDLOperation, HasRegisterConstraints):
        name = "test.allocatable"

        o = var_operand_def()
        r = var_result_def()

        traits = traits_def(RegisterAllocatedMemoryEffect())

        @override
        def iter_used_registers(self):
            yield x1

        def get_register_constraints(self) -> RegisterConstraints:
            raise NotImplementedError

    o = TestDepracatedAllocatableOp.create()

    with pytest.deprecated_call():
        assert set(RegisterAllocatedMemoryEffect.iter_used_registers(o)) == {x1}


def test_new_type_for_value():
    @irdl_attr_definition
    class OtherRegister(RegisterType):
        name = "test.other_reg"

        @classmethod
        def index_by_name(cls) -> dict[str, int]:
            return {"x0": 0, "x1": 1, "a0": 0, "a1": 1}

        @classmethod
        def infinite_register_prefix(cls):
            return "y"

    u = TestRegisterType.unallocated()
    a0 = TestRegisterType.from_name("a0")
    a1 = TestRegisterType.from_name("a1")

    available_registers = RegisterStack.get((a0, a1))
    allocator = ValueAllocator(available_registers, TestRegisterType)

    r0, r1, r2, r3 = op(
        (), u, a0, OtherRegister.unallocated(), OtherRegister.from_index(1)
    ).results

    assert allocator.new_type_for_value(r0) == a1
    assert allocator.new_type_for_value(r1) is None
    assert allocator.new_type_for_value(r2) is None
    assert allocator.new_type_for_value(r3) is None


def test_allocate_value():
    u = TestRegisterType.unallocated()
    a0 = TestRegisterType.from_name("a0")
    a1 = TestRegisterType.from_name("a1")
    y0 = TestRegisterType.from_name("y0")

    register_stack = RegisterStack.get((a0, a1), allow_infinite=True)
    allocator = ValueAllocator(register_stack, TestRegisterType)

    op0 = op((), u, u, u, u)
    r00, r01, r02, _r03 = op0.results
    op1 = op((r00, r01), u, u, inouts=(r02,))
    results00 = tuple(op0.results)
    results10 = tuple(op1.results)

    # Initial state
    assert register_stack.available_registers == {"test.reg": [0, 1]}
    assert allocator.new_value_by_old_value == {}
    assert op0.result_types == (u, u, u, u)
    assert op1.result_types == (u, u, u)

    # Allocate first result
    new_value = allocator.allocate_value(op1.out_results[0])
    assert new_value is not None

    results11 = tuple(op1.results)

    assert register_stack.available_registers == {"test.reg": [0]}
    assert allocator.new_value_by_old_value == {results10[0]: results11[0]}
    assert op0.result_types == (u, u, u, u)
    assert op1.result_types == (a1, u, u)

    # Allocate first result again (old value) -> no change of state
    new_value = allocator.allocate_value(results10[0])
    assert new_value is None
    assert register_stack.available_registers == {"test.reg": [0]}
    assert allocator.new_value_by_old_value == {results10[0]: results11[0]}
    assert op0.result_types == (u, u, u, u)
    assert op1.result_types == (a1, u, u)

    # Allocate first result again (new value) -> no change of state
    new_value = allocator.allocate_value(op1.out_results[0])
    assert new_value is None
    assert register_stack.available_registers == {"test.reg": [0]}
    assert allocator.new_value_by_old_value == {results10[0]: results11[0]}
    assert op0.result_types == (u, u, u, u)
    assert op1.result_types == (a1, u, u)

    # Allocate second result
    new_value = allocator.allocate_value(op1.out_results[1])
    assert new_value is not None

    results12 = tuple(op1.results)

    assert register_stack.available_registers == {"test.reg": []}
    assert allocator.new_value_by_old_value == {
        results10[0]: results11[0],
        results11[1]: results12[1],
    }
    assert op0.result_types == (u, u, u, u)
    assert op1.result_types == (a1, a0, u)

    # Allocate inout result and operands at the same time
    new_value = allocator.allocate_values_same_reg(
        (op1.inout_operands[0], op1.inout_results[0])
    )
    results03 = tuple(op0.results)
    results13 = tuple(op1.results)

    assert register_stack.available_registers == {"test.reg": []}
    assert allocator.new_value_by_old_value == {
        results10[0]: results11[0],
        results11[1]: results12[1],
        results12[2]: results13[2],
        results00[2]: results03[2],
    }
    assert op0.result_types == (u, u, y0, u)
    assert op1.result_types == (a1, a0, y0)

    # Free the allocated result values
    allocator.free_value(results13[0])
    allocator.free_value(results13[1])

    assert register_stack.available_registers == {"test.reg": [1, 0]}
    assert allocator.new_value_by_old_value == {
        results10[0]: results11[0],
        results11[1]: results12[1],
        results12[2]: results13[2],
        results00[2]: results03[2],
    }
    assert op0.result_types == (u, u, y0, u)
    assert op1.result_types == (a1, a0, y0)

    # Allocate operand
    allocator.allocate_value(op1.operands[0])
    results04 = tuple(op0.results)

    assert register_stack.available_registers == {"test.reg": [1]}
    assert allocator.new_value_by_old_value == {
        results10[0]: results11[0],
        results11[1]: results12[1],
        results12[2]: results13[2],
        results00[2]: results03[2],
        results00[0]: results04[0],
    }
    assert op0.result_types == (a0, u, y0, u)
    assert op1.result_types == (a1, a0, y0)


def test_allocate_values_same_reg():
    u = TestRegisterType.unallocated()
    a0 = TestRegisterType.from_name("a0")
    a1 = TestRegisterType.from_name("a1")
    y0 = TestRegisterType.from_name("y0")

    register_stack = RegisterStack.get((a0, a1))
    allocator = ValueAllocator(register_stack, TestRegisterType)

    # Empty
    assert not allocator.allocate_values_same_reg(())

    op0 = op((), u, u, u, u, u)

    # 1 unallocated
    assert allocator.allocate_values_same_reg((op0.results[0],))
    assert op0.result_types == (a1, u, u, u, u)

    # 1 allocated
    assert not allocator.allocate_values_same_reg((op0.results[0],))
    assert op0.result_types == (a1, u, u, u, u)

    # 2 unallocated
    assert allocator.allocate_values_same_reg((op0.results[1], op0.results[2]))
    assert op0.result_types == (a1, a0, a0, u, u)

    # 1 allocated 1 unallocated
    assert allocator.allocate_values_same_reg((op0.results[0], op0.results[3]))
    assert op0.result_types == (a1, a0, a0, a1, u)

    # 1 unallocated 1 allocated
    assert allocator.allocate_values_same_reg((op0.results[4], op0.results[0]))
    assert op0.result_types == (a1, a0, a0, a1, a1)

    with pytest.raises(
        DiagnosticException,
        match=re.escape(
            "Cannot allocate registers to the same register ['!test.reg<a0>', '!test.reg<a1>']"
        ),
    ):
        allocator.allocate_values_same_reg((op0.results[0], op0.results[1]))

    op1 = op((), y0)

    with pytest.raises(
        DiagnosticException,
        match=re.escape(
            "Cannot allocate registers to the same register ['!test.reg<a0>', '!test.reg<a1>', '!test.reg<y0>']"
        ),
    ):
        allocator.allocate_values_same_reg(
            (op0.results[0], op0.results[1], op1.results[0])
        )


def test_multiple_outputs():
    class AllocatableTestOp(TestOp, HasRegisterConstraints):
        def get_register_constraints(self) -> RegisterConstraints:
            # The default register constraints are that all operands are "in", and all
            # results are "out" registers.
            return RegisterConstraints(self.operands, self.results, ())

    available_registers = RegisterStack(allow_infinite=True)
    register_allocator = BlockNaiveAllocator(available_registers, TestRegisterType)

    op = AllocatableTestOp(
        result_types=(
            TestRegisterType.unallocated(),
            TestRegisterType.unallocated(),
        )
    )

    op.allocate_registers(register_allocator)

    # Check allocated registers are unique
    assert len(op.result_types) == len(set(op.result_types))


def test_verify_register_constraints():
    u = TestRegisterType.unallocated()

    # Correctly implemented `get_register_constraints` passes verification
    op([create_ssa_value(u)], u, inouts=[create_ssa_value(u)]).verify()

    # A value may be read as an `in` register and also clobbered as an `inout` register,
    # as long as it is declared once per operand.
    shared = create_ssa_value(u)
    op([shared], u, inouts=[shared]).verify()

    # The same holds for a value clobbered by more than one `inout` register.
    op([], u, inouts=[shared, shared]).verify()

    unrelated = create_ssa_value(u)

    class MisconstrainedOp(HasRegisterConstraints, IRDLOperation):
        T: ClassVar = VarConstraint("T", base(TestRegisterType))

        a = operand_def(T)
        b = result_def(T)

    @irdl_op_definition
    class UndeclaredOperandOp(MisconstrainedOp):
        name = "test.undeclared_operand"

        def get_register_constraints(self) -> RegisterConstraints:
            return RegisterConstraints((), (self.b,), ())

    @irdl_op_definition
    class RepeatedOperandOp(MisconstrainedOp):
        name = "test.repeated_operand"

        def get_register_constraints(self) -> RegisterConstraints:
            return RegisterConstraints((self.a, self.a), (self.b,), ())

    @irdl_op_definition
    class UndeclaredResultOp(MisconstrainedOp):
        name = "test.undeclared_result"

        def get_register_constraints(self) -> RegisterConstraints:
            return RegisterConstraints((self.a,), (), ())

    @irdl_op_definition
    class RepeatedResultOp(MisconstrainedOp):
        name = "test.repeated_result"

        def get_register_constraints(self) -> RegisterConstraints:
            return RegisterConstraints((self.a,), (self.b, self.b), ())

    @irdl_op_definition
    class ForeignValueOp(MisconstrainedOp):
        name = "test.foreign_value"

        def get_register_constraints(self) -> RegisterConstraints:
            return RegisterConstraints((self.a, unrelated), (self.b,), ())

    for op_type, message in (
        (
            UndeclaredOperandOp,
            "Operation test.undeclared_operand operand at index 0 is declared 0 times as `in` or `inout`, expected 1.",
        ),
        (
            RepeatedOperandOp,
            "Operation test.repeated_operand operand at index 0 is declared 2 times as `in` or `inout`, expected 1.",
        ),
        (
            UndeclaredResultOp,
            "Operation test.undeclared_result result at index 0 is declared 0 times as `out` or `inout`, expected 1.",
        ),
        (
            RepeatedResultOp,
            "Operation test.repeated_result result at index 0 is declared 2 times as `out` or `inout`, expected 1.",
        ),
        (
            ForeignValueOp,
            "Operation test.foreign_value declares values as `in` or `inout` that it "
            "does not use as operands.",
        ),
    ):
        misconstrained = op_type(operands=[create_ssa_value(u)], result_types=[u])
        with pytest.raises(VerifyException, match=re.escape(message)):
            misconstrained.verify()


def test_fail_error_message():
    @irdl_op_definition
    class InoutOp(HasRegisterConstraints, IRDLOperation):
        name = "test.inout"

        T: ClassVar = VarConstraint("T", base(TestRegisterType))

        a = operand_def(T)
        b = result_def(T)

        def get_register_constraints(self) -> RegisterConstraints:
            return RegisterConstraints((), (), ((self.a, self.b),))

    a = create_ssa_value(TestRegisterType.from_index(0))
    block = Block(
        (InoutOp(operands=[a], result_types=[TestRegisterType.from_index(1)]),)
    )

    allocator = BlockNaiveAllocator(RegisterStack.get(), TestRegisterType)

    with pytest.raises(
        DiagnosticException,
        match=re.escape(
            "Cannot allocate registers to the same register ['!test.reg<a0>', '!test.reg<a1>']"
        ),
    ) as e:
        allocator.allocate_block(block)

    assert getattr(e.value, "__notes__") == [
        """
^bb0:
  %0 = "test.inout"(%1) : (!test.reg<a0>) -> !test.reg<a1>
  ^^^^^^^^^^^^^^^^^----
  | Error allocating op
  ---------------------
"""
    ]


def test_out_of_registers():
    register_stack = RegisterStack()
    with pytest.raises(OutOfRegisters, match="Out of registers."):
        register_stack.pop(TestRegisterType)


def test_reserved_aliased_register():
    assert TestAliasRegisterA.register_pool_key() != TestAliasRegisterA.name

    stack = RegisterStack.get((TestAliasRegisterA.from_index(0),))
    r = stack.pop(TestAliasRegisterB)
    assert r == TestAliasRegisterB.from_index(0)

    stack.push(r)
    stack.reserve_register(r)
    with pytest.raises(AssertionError, match="Cannot pop a reserved register"):
        stack.pop(TestAliasRegisterA)


def test_register_pool_key_alias_pool_shares_physical_indices():
    """
    Two register types with different IR names but the same register_pool_key() must
    draw from one pool of ABI indices.
    """
    stack = RegisterStack.get(
        (
            TestAliasRegisterA.from_name("p0"),
            TestAliasRegisterB.from_name("q0"),
        )
    )
    assert stack.available_registers["test.alias_pool"] == [0]
    assert stack.pop(TestAliasRegisterA) == TestAliasRegisterA.from_index(0)
    with pytest.raises(OutOfRegisters):
        stack.pop(TestAliasRegisterB)


def test_register_pool_key_alias_exclude_by_index():
    stack = RegisterStack.get(
        (
            TestAliasRegisterA.from_name("p0"),
            TestAliasRegisterA.from_name("p1"),
        )
    )
    stack.exclude_register(TestAliasRegisterB.from_name("q0"))
    assert 0 not in stack.available_registers["test.alias_pool"]
    assert stack.available_registers["test.alias_pool"] == [1]
