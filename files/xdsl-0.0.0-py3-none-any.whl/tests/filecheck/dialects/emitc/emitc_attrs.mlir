// RUN: XDSL_ROUNDTRIP

//===----------------------------------------------------------------------===//
// OpaqueAttr
//===----------------------------------------------------------------------===//

"test.op"() {
  // CHECK: opaque_attr = #emitc.opaque<"some_value">
  opaque_attr = #emitc.opaque<"some_value">,
  // CHECK-SAME: quoted_attr = #emitc.opaque<"\22quoted_attr\22">
  quoted_attr = #emitc.opaque<"\"quoted_attr\"">
}: () -> ()
