from xdsl.irdl import *
from xdsl.ir import *


@irdl_attr_definition
class parametric(ParametrizedAttribute, TypeAttribute):
    name = "testd.parametric"
    elem: Attribute


@irdl_attr_definition
class parametric_attr(ParametrizedAttribute):
    name = "testd.parametric_attr"
    elem: Attribute


@irdl_attr_definition
class attr_in_type_out(ParametrizedAttribute, TypeAttribute):
    name = "testd.attr_in_type_out"
    param: Attribute


@irdl_op_definition
class MyEqOp(IRDLOperation):
    name = "testd.my_eq"
    out = result_def()
    regs = var_region_def()
    succs = var_successor_def()


@irdl_op_definition
class AnyOfOp(IRDLOperation):
    name = "testd.any_of"
    out = result_def()
    regs = var_region_def()
    succs = var_successor_def()


@irdl_op_definition
class AllOfOp(IRDLOperation):
    name = "testd.all_of"
    out = result_def()
    regs = var_region_def()
    succs = var_successor_def()


@irdl_op_definition
class AnyOp(IRDLOperation):
    name = "testd.any"
    out = result_def()
    regs = var_region_def()
    succs = var_successor_def()


@irdl_op_definition
class DynbaseOp(IRDLOperation):
    name = "testd.dynbase"
    out = result_def()
    regs = var_region_def()
    succs = var_successor_def()


@irdl_op_definition
class DynparamsOp(IRDLOperation):
    name = "testd.dynparams"
    out = result_def()
    regs = var_region_def()
    succs = var_successor_def()


@irdl_op_definition
class ConstraintVarsOp(IRDLOperation):
    name = "testd.constraint_vars"
    out1 = result_def()
    out2 = result_def()
    regs = var_region_def()
    succs = var_successor_def()


testd = Dialect("testd", [MyEqOp, AnyOfOp, AllOfOp, AnyOp, DynbaseOp, DynparamsOp, ConstraintVarsOp], [parametric, parametric_attr, attr_in_type_out])
